// DealDialog.cpp: implementation of the CIMDealDialog class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "IMDealDialog.h"
#include "DealItem.h"
#include "ItemManager.h"
#include "ObjectManager.h"
#include "MoveManager.h"
#include "WindowIDEnum.h"
#include "./Interface/cWindowManager.h"
#include "./Interface/cIconGridDialog.h"
#include "./Interface/cStatic.h"
#include "./interface/cTabDialog.h"
#include "./interface/cPushupButton.h"
#include "GameIn.h"
#include "ObjectStateManager.h"
#include "cDivideBox.h"
#include "InventoryExDialog.h"
#include "mhFile.h"
#include "cMsgBox.h"
#include "ChatManager.h"
#include "MHMap.h"
#include "FishingManager.h"
#include "PCRoomManager.h"
//aziz MallShop 24
#include "VipMgr.h"
//aziz Kill Shop 30 Sep
#include "KillMgr.h"
//aziz Reborn Point 13 Oct
#include "UtilityMgr.h"
#include "ChaptchaDlg.h"

//Alemuri Calendar Daily Item----
#include <time.h>
//-------------------------------

#include "cScriptManager.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

void BuyItem(LONG lId, void * p, DWORD we);

CIMDealDialog::CIMDealDialog()
{
	m_type = WT_IMDEALDIALOG;
	m_pMoneyEdit = NULL;
	m_CurSelectedItemIdx = 0;
	m_lCurSelItemPos = -1;
	m_IMDealerTable.Initialize(32);			// #define MAX_DEALER_NUM 100
	m_fShow = FALSE;

	m_DealerIdx = 0;
}

CIMDealDialog::~CIMDealDialog()
{
	Release();
}


void CIMDealDialog::Add(cWindow * window)
{
	if(window->GetType() == WT_PUSHUPBUTTON)
		AddTabBtn(curIdx1++, (cPushupButton * )window);
	else if(window->GetType() == WT_ICONGRIDDIALOG)
		AddTabSheet(curIdx2++, window);
	else 
		cDialog::Add(window);
}

void CIMDealDialog::ShowDealer(WORD DealerKey)
{
	if(m_fShow) HideDealer();
	SelectTab(0);
	SetMoney(0, 2);

	IMDealerData * pDealer = m_IMDealerTable.GetData(DealerKey);
	if(pDealer == NULL)
	{
		//070126 LYW --- NPCShop : Modified message number.
		//CHATMGR->AddMsg( CTC_SYSMSG, CHATMGR->GetChatMsg(197) );
		CHATMGR->AddMsg( CTC_SYSMSG, CHATMGR->GetChatMsg(338) );
		if( HERO->GetState() == eObjectState_Deal )
			OBJECTSTATEMGR->EndObjectState(HERO, eObjectState_Deal);
		return;
	}

	SetActive(TRUE);
	
	for(BYTE i = 0; i < m_bTabNum; ++i )
	{
		cPushupButton* Btn = GetTabBtn(i);
		Btn->SetActive(FALSE);
	}

	CDealItem* pItem = NULL;
	cImage tmpImage;
	m_DealerIdx = DealerKey;
	DWORD DealIdx = 0;
	POS pos = pDealer->m_DealItemList.GetFirstPos();

	for(IMDealerItem* pDealItem = pDealer->m_DealItemList.GetNextPos(pos);
		0 < pDealItem;
		pDealItem = pDealer->m_DealItemList.GetNextPos(pos))
	{
		pItem = new CDealItem;
		pItem->Init(0,0,DEFAULT_ICONSIZEIM,DEFAULT_ICONSIZEIM, ITEMMGR->GetIconImage(pDealItem->ItemIdx, &tmpImage),IG_DEALITEM_START+DealIdx++);
		pItem->SetData(pDealItem->ItemIdx);
		pItem->SetItemIdx(pDealItem->ItemIdx);
		//pItem->SetMovable(FALSE);

		ITEMMGR->AddToolTip( pItem );
		
		char buf[MAX_PATH] = {0};
		pItem->AddToolTipLine("");

		if(pItem->GetBuyPrice())
		{
			wsprintf(
				buf,
				CHATMGR->GetChatMsg(35),
				AddComma(pItem->GetBuyPrice()));
			pItem->AddToolTipLine(
				buf,
				TTTC_BUYPRICE);
		}

		if(0 < pItem->GetBuyFishPoint())
		{
			wsprintf( buf, CHATMGR->GetChatMsg(1540), AddComma(pItem->GetBuyFishPoint()) );
			pItem->AddToolTipLine( buf, TTTC_BUYPRICE );
		}
		
		if(0 < pItem->GetBuyVipPoint())
		{
			wsprintf( buf, CHATMGR->GetChatMsg(2501), AddComma(pItem->GetBuyVipPoint()) );
			pItem->AddToolTipLine( buf, TTTC_BUYPRICE );
		}
		
		if(0 < pItem->GetBuyKillPoint())
		{
			wsprintf( buf, CHATMGR->GetChatMsg(2504), AddComma(pItem->GetBuyKillPoint()) );
			pItem->AddToolTipLine( buf, TTTC_BUYPRICE );
		}
		
		if(0 < pItem->GetBuyRebornPoint())
		{
			wsprintf( buf, CHATMGR->GetChatMsg(2509), AddComma(pItem->GetBuyRebornPoint()) );
			pItem->AddToolTipLine( buf, TTTC_BUYPRICE );
		}
		// 100104 ShinJS --- Item Point Type�� ���� ���� �߰�
		pItem->AddPointTypeToolTip();

		// 090114 LYW --- DealDialog : ������ ���� ���� üũ �Լ� ������ ���� ó��.
		if( ITEMMGR->CanEquip(pDealItem->ItemIdx) == eEquip_Disable )
			pItem->SetToolTipImageRGB( TTCLR_ITEM_CANNOTEQUIP ) ;

		WINDOWMGR->AddWindow(pItem);

		//int position = pDealItem->Pos;
		//position += (pDealItem->Tab * 36);
		//int imageIndex = GetHardImageForIMSlot(position);
		//SCRIPTMGR->GetImage(imageIndex, &m_ImageSlot);
		//pItem->SetBasicImage(&m_ImageSlot);
		
		cIconGridDialog * dlg = (cIconGridDialog *)GetTabSheet(pDealItem->Tab);
		dlg->AddIcon(pDealItem->Pos, pItem);

		//SW050819 
		cPushupButton* Btn = GetTabBtn(pDealItem->Tab);
		if( !Btn->IsActive() )
		{
			Btn->SetActive(TRUE);
		}
	}
	
	if (DealerKey != 9991) //Alemuri IM Dealer (only open inventory if it's not IM Dealer)
		GAMEIN->GetInventoryDialog()->SetActive(TRUE);

	m_CurSelectedItemIdx	= 0;
	m_lCurSelItemPos		= -1;
	m_fShow = TRUE;

	ITEMMGR->SetPriceToItem( TRUE );

	if (DealerKey == 9991)
	{
		m_pTitle = (cStatic *)GetWindowForID(IMSTATIC_TITLE);
		if (m_pTitle)
		{
			m_pTitle->SetStaticText("IM Shop");
		}
	}
}

void CIMDealDialog::HideDealer()
{
	if(!m_fShow) return;

	
	cIcon* pIcon;

	for(BYTE tab=0;tab<m_bTabNum;++tab)
	{
		cIconGridDialog * dlg = (cIconGridDialog *)GetTabSheet(tab);

		for(WORD n=0;n<dlg->m_nCol*dlg->m_nRow;++n)
		{
			pIcon = dlg->GetIconForIdx(n);
			if(pIcon != NULL)
			{
				dlg->DeleteIcon(pIcon);
				//delete pIcon;
				pIcon->SetActive( FALSE );
				WINDOWMGR->AddListDestroyWindow( pIcon );
				pIcon = NULL;
			}
			
		}
	}
	m_DealerIdx = 0;

//KES ���� WINDOMGR->AddListDestroyWindow( pIcon ) �� ��ü.�Ͽ���
//process �߿� �ٷ� delete�����ÿ� ������ ����.
//	for(DWORD n=0;n<m_DealIdx;++n)
//	{
//		WINDOWMGR->DeleteWindowForID(IG_DEALITEM_START+n);
//	}

//���� ���¿��� ���� ���� �ִ�. üũ�ϴ°� �߰� �ʿ�
	if( HERO->GetState() != eObjectState_Die )
	{
		if( HERO->GetState() == eObjectState_Deal  )
		OBJECTSTATEMGR->EndObjectState(HERO,eObjectState_Deal);
	}

	m_fShow = FALSE;

	ITEMMGR->SetPriceToItem( FALSE );
}


void CIMDealDialog::LoadDealerItem(CMHFile* fp)
{
	char buff[2048];
	char mapname[256];
	char npcname[256];
	DWORD ItemIdx;
	
	IMDealerItem* pItem;
	IMDealerData* pCurDealer = NULL;
	char seps[]   = "\t\n";
	char* token;
	int count = 0;
	while(1)
	{
		if(fp->IsEOF())
		{
			break;
		}
		count++;
		fp->GetWord(); // map index
		fp->GetString(mapname);
		fp->GetWord(); // npc kind
		fp->GetString(npcname);
		WORD npc_index = fp->GetWord();
		fp->GetWord(); // point x
		fp->GetWord(); // point y
		fp->GetWord(); // angle
		BYTE tabnum = fp->GetByte();
		BYTE Pos = 0;
		
		fp->GetLine(buff,2048);

		token = strtok( buff, seps );
		if(token == NULL)
			continue;
		token = strtok( NULL, seps );
		ItemIdx = atoi(token);

		pCurDealer = m_IMDealerTable.GetData(npc_index);
		if(pCurDealer == NULL)
		{
			pCurDealer = new IMDealerData;
			m_IMDealerTable.Add(pCurDealer,npc_index);
		}
		

		if( ItemIdx != 0 )
		{
			pItem = new IMDealerItem;
			ASSERT(tabnum)
			pItem->Tab = tabnum-1;
			pItem->Pos = Pos++;
			pItem->ItemIdx = ItemIdx;
			pCurDealer->m_DealItemList.AddTail(pItem);
		}
		else
		{
			Pos++;
		}

		while( 1 )
		{
			token = strtok( NULL, seps );
			if(token == NULL)
				break;
			token = strtok( NULL, seps );
			ItemIdx = atoi(token);
			
			if( ItemIdx != 0 )
			{
				pItem = new IMDealerItem;
				pItem->Tab = tabnum-1;
				pItem->Pos = Pos++;
				pItem->ItemIdx = ItemIdx;
				pCurDealer->m_DealItemList.AddTail(pItem);
			}
			else
			{
				Pos++;
			}
		}		
	}
}
void CIMDealDialog::Linking()
{
	m_pMoneyEdit = (cStatic *)GetWindowForID(IMDE_MONEYEDIT);
	m_pMoneyEdit->SetTextXY( 4, 4 );
	m_pMoneyEdit->SetAlign( TXT_RIGHT );

	// 100104 ShinJS --- PC�� ����Ʈ ��� Static �߰�
	m_pPointImage = (cStatic *)GetWindowForID(IMDE_POINTIMG);
	m_pPointImage->SetActive( FALSE );

	m_pPointEdit = (cStatic *)GetWindowForID(IMDE_POINTEDIT);
	m_pPointEdit->SetActive( FALSE );
}
void CIMDealDialog::Release()
{
	m_IMDealerTable.SetPositionHead();

	for(IMDealerData* pDealer = m_IMDealerTable.GetData();
		0 < pDealer;
		pDealer = m_IMDealerTable.GetData())
	{
		POS pos = pDealer->m_DealItemList.GetFirstPos();

		for(IMDealerItem* pIMDealerItem = pDealer->m_DealItemList.GetNextPos( pos );
			0 < pIMDealerItem;
			pIMDealerItem = pIMDealerItem = pDealer->m_DealItemList.GetNextPos( pos ))
		{
			delete pIMDealerItem;
		}

		pDealer->m_DealItemList.DeleteAll();
		delete pDealer;
	}
	m_IMDealerTable.RemoveAll();
}

void CIMDealDialog::OnSelectedItem()
{	
	cIconGridDialog * gridDlg = (cIconGridDialog *)GetTabSheet(GetCurTabNum());
	CDealItem* pItem = (CDealItem*)gridDlg->GetIconForIdx((WORD)gridDlg->GetCurSelCellPos());
	if(!pItem)
	{
		SetMoney(0, 2);
		m_CurSelectedItemIdx	= 0;
		m_lCurSelItemPos		= -1;
		return;
	}

	m_CurSelectedItemIdx	= pItem->GetItemIdx();
	m_lCurSelItemPos		= gridDlg->GetCurSelCellPos();
	ITEM_INFO * pItemInfo = ITEMMGR->GetItemInfo(m_CurSelectedItemIdx);
	
	SetMoney(pItemInfo->BuyPrice, 1);
}
void CIMDealDialog::Render()
{
	cDialog::RenderWindow();
	cDialog::RenderComponent();
	cTabDialog::RenderTabComponent();
}

void CIMDealDialog::SetMoney(MONEYTYPE value, BYTE colorType)
{
	if(colorType == 0)		//�Ĵ°���ǥ��
		m_pMoneyEdit->SetFGColor(RGB_HALF(255,0,0));
	else if(colorType == 1)	//��°���ǥ��
		// 080401 LYW --- DealDialog : Change text color.
		//m_pMoneyEdit->SetFGColor(TTTC_BUYPRICE);
		m_pMoneyEdit->SetFGColor(RGB_HALF(10, 10, 10));
	else
		// 080401 LYW --- DealDialog : change text color.
		//m_pMoneyEdit->SetFGColor(RGB_HALF(255,255,255));
		m_pMoneyEdit->SetFGColor(RGB_HALF(255, 0, 0));

	//m_pMoneyEdit->SetStaticText( AddComma( value ) );
	m_pMoneyEdit->SetStaticText( "" );
}

void CIMDealDialog::SellItem(CItem* pItem)
{
	if(0 == pItem)
	{
		return;
	}
	else if(pItem->IsLocked())
	{
		return;
	}

	const ITEM_INFO* const pItemInfo = ITEMMGR->GetItemInfo( pItem->GetItemIdx() );

	if(0 == pItemInfo)
	{
		return;
	}
	else if(FALSE == pItemInfo->Sell)
	{
		return;
	}

	if (m_DealerIdx == 9991)
		return;

	SetDisable( TRUE );
	GAMEIN->GetInventoryDialog()->SetDisable( TRUE );

	if(pItemInfo->Stack && pItem->GetDurability() > 1)
	{
		m_sellMsg.Category = MP_ITEM;
		m_sellMsg.Protocol = MP_ITEM_SELL_SYN;
		m_sellMsg.dwObjectID = HEROID;
		m_sellMsg.TargetPos	= pItem->GetPosition();
		m_sellMsg.SellItemNum = WORD(pItem->GetDurability());
		m_sellMsg.wSellItemIdx = pItem->GetItemIdx();
		m_sellMsg.wDealerIdx = m_DealerIdx;

		cDivideBox * pDivideBox = WINDOWMGR->DivideBox(
			DBOX_SELL, 
			LONG(pItem->GetAbsX()),
			LONG(pItem->GetAbsY()),
			OnFakeSellItem,
			OnCancelSellItem,
			this,
			pItem,
			CHATMGR->GetChatMsg(26));

		pDivideBox->SetValue(
			pItem->GetDurability());
		pDivideBox->SetMaxValue(
			pItemInfo->Stack);
	}
	else
	{
		m_sellMsg.Category = MP_ITEM;
		m_sellMsg.Protocol = MP_ITEM_SELL_SYN;
		m_sellMsg.dwObjectID = HEROID;
		m_sellMsg.TargetPos	= pItem->GetPosition();
		m_sellMsg.SellItemNum = WORD(pItem->GetDurability());
		m_sellMsg.wSellItemIdx = pItem->GetItemIdx();
		m_sellMsg.wDealerIdx = m_DealerIdx;

		if(pItemInfo->EquipType == eEquipType_Weapon || pItemInfo->EquipType == eEquipType_Armor || pItemInfo->EquipType == eEquipType_Accessary)
		{
			const ITEM_OPTION& option	= ITEMMGR->GetOption(pItem->GetItemBaseInfo());
			char msgfull[256];
			sprintf(msgfull, CHATMGR->GetChatMsg(339), pItemInfo->ItemName, AddComma(pItemInfo->SellPrice));
				
			if(option.mEnchant.mLevel >= 12)
			{
				CChaptchaDlg* ChaptchaDlg = (CChaptchaDlg*)GAMEIN->GetChaptchaDlg();
				if(!ChaptchaDlg)
				{
					ChaptchaDlg->SetTypeCaptcha(4);
					//ChaptchaDlg->SetItemnameTodelete(itemnya);
					ChaptchaDlg->SetFullmsg(msgfull);
					ChaptchaDlg->SetTypeGame(FALSE);
					ChaptchaDlg->SetActive(TRUE);
					CHATMGR->AddMsg( CTC_OPERATEITEM, "Are you sure to sell this item? we are detect this item enchant level 12+. Please fill captcha!" );
				} else {
					ChaptchaDlg->SetTypeCaptcha(4);
					//ChaptchaDlg->SetItemnameTodelete(itemnya);
					ChaptchaDlg->SetFullmsg(msgfull);
					ChaptchaDlg->SetTypeGame(FALSE);
					ChaptchaDlg->SetActive(TRUE);
					CHATMGR->AddMsg( CTC_OPERATEITEM, "Are you sure to sell this item? we are detect this item enchant level 12+. Please fill captcha!" );
				}
			} else {
				WINDOWMGR->MsgBox(
				MBI_IMSELLITEM,
				MBT_YESNO, 
				CHATMGR->GetChatMsg(339),
				pItemInfo->ItemName,
				AddComma(pItemInfo->SellPrice));
			}
		} else {
			WINDOWMGR->MsgBox(
				MBI_IMSELLITEM,
				MBT_YESNO, 
				CHATMGR->GetChatMsg(339),
				pItemInfo->ItemName,
				AddComma(pItemInfo->SellPrice));
		}
	}
}

BOOL CIMDealDialog::FakeMoveIcon(LONG x, LONG y, cIcon * icon)
{
	// 090106 LYW --- DealDialog : â�� ��ȯ �������� ����Ͽ�, 
	// â������ �������� �ٷ� �Ǹ� �Ҽ� �ִ� ���׸� �����Ѵ�.


	// �Լ����� Ȯ��.
	if( !icon ) return FALSE ;


	// ������ Ÿ������ Ȯ��.
	if( icon->GetType() != WT_ITEM ) return FALSE ;

	if (m_DealerIdx == 9991)
		return FALSE;

	// ������ ������ �޴´�.
	CItem * pItem = ( CItem * )icon ;
	if( !pItem ) return FALSE ;

    ITEM_INFO* pItemInfo = ITEMMGR->GetItemInfo( ((CItem*)icon)->GetItemIdx() ) ;	
	if( !pItemInfo ) return FALSE ;


	// �Ǹ� ���� ���������� Ȯ���Ѵ�.
	if( !pItemInfo->Sell ) return FALSE ;
	
	const eITEMTABLE tableIdx = ITEMMGR->GetTableIdxForAbsPos(
		pItem->GetPosition());

	if( tableIdx != eItemTable_Inventory )
	{
		CHATMGR->AddMsg( CTC_SYSMSG, CHATMGR->GetChatMsg( 1809 ) ) ;
		return FALSE ;
	}


	// �Ǹ� �޽����� �����Ѵ�.
	m_sellMsg.Category			= MP_ITEM ;
	m_sellMsg.Protocol			= MP_ITEM_SELL_SYN ;
	m_sellMsg.dwObjectID		= HEROID ;

	m_sellMsg.TargetPos			= pItem->GetPosition() ;
	m_sellMsg.SellItemNum		= (WORD)pItem->GetDurability() ;
	m_sellMsg.wSellItemIdx		= pItem->GetItemIdx() ;
	m_sellMsg.wDealerIdx		= m_DealerIdx ;


	// ���þ������̰� �ϳ� �̻��� �������� �Ǹ� �Ϸ��� ���,
	if( ITEMMGR->IsDupItem( pItem->GetItemIdx() ) && pItem->GetDurability() > 1 )
	{
		// �Ǹ� ���� �Է� â�� Ȱ��ȭ �Ѵ�.
		cDivideBox * pDivideBox = WINDOWMGR->DivideBox( DBOX_SELL, (LONG)pItem->GetAbsX(), (LONG)pItem->GetAbsY(),
			OnFakeSellItem, OnCancelSellItem, this, pItem, CHATMGR->GetChatMsg(26) ) ;
		pDivideBox->SetValue( m_sellMsg.SellItemNum ) ;

		// 091215 ONS ������Stack�ִ���� �����ۺ��� ������ ������ ó���Ѵ�.
		pDivideBox->SetMaxValue( pItemInfo->Stack ) ;
	}
	// ���� �������̶��, �Ǹ� �ϰڴ��� Ȯ���ϴ� �޼��� â�� Ȱ��ȭ �Ѵ�.
	else
	{	
		if(pItemInfo->EquipType == eEquipType_Weapon || pItemInfo->EquipType == eEquipType_Armor || pItemInfo->EquipType == eEquipType_Accessary )
		{
			const ITEM_OPTION& option	= ITEMMGR->GetOption(pItem->GetItemBaseInfo());
			char msgfull[256];
			sprintf(msgfull, CHATMGR->GetChatMsg(339), pItemInfo->ItemName, AddComma(pItemInfo->SellPrice));
				
			if(option.mEnchant.mLevel >= 12)
			{
				CChaptchaDlg* ChaptchaDlg = (CChaptchaDlg*)GAMEIN->GetChaptchaDlg();
				if(!ChaptchaDlg)
				{
					ChaptchaDlg->SetTypeCaptcha(4);
					//ChaptchaDlg->SetItemnameTodelete(itemnya);
					ChaptchaDlg->SetFullmsg(msgfull);
					ChaptchaDlg->SetTypeGame(FALSE);
					ChaptchaDlg->SetActive(TRUE);
					CHATMGR->AddMsg( CTC_OPERATEITEM, "Are you sure to sell this item? we are detect this item enchant level 12+. Please fill captcha!" );
				} else {
					ChaptchaDlg->SetTypeCaptcha(4);
					//ChaptchaDlg->SetItemnameTodelete(itemnya);
					ChaptchaDlg->SetFullmsg(msgfull);
					ChaptchaDlg->SetTypeGame(FALSE);
					ChaptchaDlg->SetActive(TRUE);
					CHATMGR->AddMsg( CTC_OPERATEITEM, "Are you sure to sell this item? we are detect this item enchant level 12+. Please fill captcha!" );
				}
			} else {
				WINDOWMGR->MsgBox(
				MBI_IMSELLITEM,
				MBT_YESNO, 
				CHATMGR->GetChatMsg(339),
				pItemInfo->ItemName,
				AddComma(pItemInfo->SellPrice));
			}
		} else {
			WINDOWMGR->MsgBox(
				MBI_IMSELLITEM,
				MBT_YESNO, 
				CHATMGR->GetChatMsg(339),
				pItemInfo->ItemName,
				AddComma(pItemInfo->SellPrice));
		}
		/*
		WINDOWMGR->MsgBox(
			MBI_SELLITEM,
			MBT_YESNO,
			CHATMGR->GetChatMsg(339),
			pItemInfo->ItemName,
			AddComma( pItemInfo->SellPrice ));
			*/
	}


	// ����â�� Disable ��Ų��.
	SetDisable( TRUE ) ;


	// �κ��丮�� Disable ��Ų��.
	CInventoryExDialog* pInvenDlg = GAMEIN->GetInventoryDialog() ;
	if( pInvenDlg )
	{
		pInvenDlg->SetDisable( TRUE ) ;
	}

	return FALSE ;
}

void CIMDealDialog::OnFakeSellItem( LONG iId, void* p, DWORDEX param1, void * vData1, void * vData2 )
{
	CIMDealDialog * tDlg = ( CIMDealDialog * )vData1;
	CItem* pItem = (CItem*)vData2;
	ASSERT( pItem );

	if( param1 == 0 ) 
	{
		ITEMMGR->SetDisableDialog(FALSE, eItemTable_IMDeal);
		ITEMMGR->SetDisableDialog(FALSE, eItemTable_Inventory);
		return;
	}

	tDlg->m_sellMsg.SellItemNum = (WORD)((tDlg->m_sellMsg.SellItemNum > param1 ? param1 : tDlg->m_sellMsg.SellItemNum));

	WORD SellNum = tDlg->m_sellMsg.SellItemNum;
	if(! ITEMMGR->IsDupItem( tDlg->m_sellMsg.wSellItemIdx ))
		SellNum = 1;

	char temp[32] = {0};
	SafeStrCpy(temp, AddComma(pItem->GetItemInfo()->SellPrice), 32);
	WINDOWMGR->MsgBox(
		MBI_IMSELLITEM,
		MBT_YESNO,
		CHATMGR->GetChatMsg(340),
		pItem->GetItemInfo()->ItemName,
		SellNum,
		temp,
		AddComma(pItem->GetItemInfo()->SellPrice * SellNum));
}

void CIMDealDialog::OnCancelSellItem( LONG iId, void* p, DWORDEX param1, void * vData1, void * vData2 )
{
	CIMDealDialog * tDlg = ( CIMDealDialog * )vData1;

	tDlg->SetDisable( FALSE );
	GAMEIN->GetInventoryDialog()->SetDisable( FALSE );
}


void CIMDealDialog::SendSellItemMsg()
{
	const eITEMTABLE TargetTableIdx = ITEMMGR->GetTableIdxForAbsPos(m_sellMsg.TargetPos);
	CItem* pTargetItem = ITEMMGR->GetItemofTable(TargetTableIdx, m_sellMsg.TargetPos);

	if(!pTargetItem)
	{
		OnCancelSellItem(0, NULL, 0, this, NULL);
		return ;
	}

	if(m_sellMsg.wSellItemIdx != pTargetItem->GetItemIdx())
	{
		OnCancelSellItem(0, NULL, 0, this, NULL);
		return ;
	}
	if(m_sellMsg.SellItemNum > pTargetItem->GetDurability())
	{
		OnCancelSellItem(0, NULL, 0, this, NULL);
		return ;
	}

	NETWORK->Send( &m_sellMsg, sizeof(m_sellMsg) );
}

void CIMDealDialog::OnSellPushed()
{
	if(CItem* const pItem = GAMEIN->GetInventoryDialog()->GetCurSelectedItem(eItemTable_Inventory))
	{
		FakeMoveIcon(
			LONG(pItem->GetAbsX() + 20),
			LONG(pItem->GetAbsY() + 20),
			pItem);
	}
}

void CIMDealDialog::OnFakeBuyItem( LONG iId, void* p, DWORDEX param1, void * vData1, void * vData2 )
{
/*	// ��� �ִ��� üũ ��
	tDlg->m_buyMsg.BuyItemNum	= param1;
	NETWORK->Send( &tDlg->m_buyMsg, sizeof(tDlg->m_buyMsg) );
*/
	if( param1 == 0 )
	{
		ITEMMGR->SetDisableDialog(FALSE, eItemTable_IMDeal);
		ITEMMGR->SetDisableDialog(FALSE, eItemTable_Inventory);
		return;
	}

	CIMDealDialog * tDlg = ( CIMDealDialog * )vData1;
	CDealItem* pItem = (CDealItem*)vData2;
	ASSERT( pItem );

	tDlg->m_buyMsg.BuyItemNum	= (WORD)param1;

	ITEM_INFO * pItemInfo = ITEMMGR->GetItemInfo( pItem->GetItemIdx() );
	if( !pItemInfo )
		return;

	switch( pItemInfo->wPointType )
	{
		// PC�� ����Ʈ ����
	case eItemPointType_PCRoomPoint:
		{
			DWORD dwNeedPoint = pItemInfo->dwPointTypeValue1 * tDlg->m_buyMsg.BuyItemNum;

			char totalPrice[32], totalPoint[32];
			SafeStrCpy( totalPrice, AddComma( pItem->GetBuyPrice() * tDlg->m_buyMsg.BuyItemNum ), 32 );
			SafeStrCpy( totalPoint, AddComma( dwNeedPoint ), 32 );

			WINDOWMGR->MsgBox(
				MBI_IMBUYITEM,
				MBT_YESNO,
				CHATMGR->GetChatMsg( 2015 ),
				pItem->GetItemName(),
				tDlg->m_buyMsg.BuyItemNum,
				AddComma(pItem->GetBuyPrice()),
				totalPrice,
				totalPoint );
		}
		break;
	default:
		{
			ITEM_INFO* itemInfo = ITEMMGR->GetItemInfo(pItem->GetItemIdx());
			DWORD iMPoints = 0;
			if (itemInfo)
			{
				iMPoints = itemInfo->dwBuyVipPoint;
			}
			// [07-02-2012] Death Check Item buy more than 4000 M ??
			char temp[32] = {0};
			SafeStrCpy(temp, AddComma(iMPoints), 32);
			DWORDEX totalprice = iMPoints * (DWORDEX)tDlg->m_buyMsg.BuyItemNum;
			if (totalprice <= MAX_INVENTORY_MONEY)
			{
				WINDOWMGR->MsgBox(MBI_IMBUYITEM, MBT_YESNO, "%s, Qty: %d^nAre you going to buy the item for %s IM Points per unit (total %s IM Points)?", pItem->GetItemName(), tDlg->m_buyMsg.BuyItemNum, temp,
					AddComma(iMPoints * tDlg->m_buyMsg.BuyItemNum));
			}
			// Added by Death
			else
			{
				CHATMGR->AddMsg(CTC_BUYITEM, CHATMGR->GetChatMsg(506));
				ITEMMGR->SetDisableDialog(FALSE, eItemTable_IMDeal);
				ITEMMGR->SetDisableDialog(FALSE, eItemTable_Inventory);
				return;
			}
		}
		break;
	}

	
	
}

void CIMDealDialog::OnCancelBuyItem( LONG iId, void* p, DWORDEX param1, void * vData1, void * vData2 )
{
	CIMDealDialog * tDlg = ( CIMDealDialog * )vData1;
	tDlg->SetDisable( FALSE );
	GAMEIN->GetInventoryDialog()->SetDisable( FALSE );
}

void CIMDealDialog::OnBuyPushed()
{
	if(m_lCurSelItemPos == -1)
		return;
	
	if (m_DealerIdx == 9991)
	{
	
	}

	cIconGridDialog * gridDlg = (cIconGridDialog *)GetTabSheet(GetCurTabNum());
	CDealItem* pItem = (CDealItem*)gridDlg->GetIconForIdx((WORD)m_lCurSelItemPos);

	if( pItem )
	{
		FakeBuyItem( (LONG)(pItem->GetAbsX()+20), (LONG)(pItem->GetAbsY()+20), pItem);
	}
}


void CIMDealDialog::SendBuyItemMsg()
{
	// 100104 ShinJS --- Item Point Type ����
	ITEM_INFO * pItemInfo = ITEMMGR->GetItemInfo( m_buyMsg.wBuyItemIdx );
	if( !pItemInfo )
		return;
    
	switch( pItemInfo->wPointType )
	{
		// Coin ���� Item
	case eItemPointType_Item:
		{
			// Coin �������� ���ŷ����� ������ ���
			DWORD dwCoinItemIdx = pItemInfo->dwPointTypeValue1;
			DWORD dwNeedCoinCnt = pItemInfo->dwPointTypeValue2;
			if( !CanBuyCoinItem( m_buyMsg.wBuyItemIdx, dwCoinItemIdx, dwNeedCoinCnt * m_buyMsg.BuyItemNum ) )
			{
				SetDisable( FALSE );
				GAMEIN->GetInventoryDialog()->SetDisable( FALSE );
				return;
			}
		}
		break;

		// PC�� ����Ʈ ����
	case eItemPointType_PCRoomPoint:
		{
			DWORD dwNeedPoint = pItemInfo->dwPointTypeValue1 * m_buyMsg.BuyItemNum;

			// ����Ʈ ����
			if( !PCROOMMGR->CanBuyItem( m_buyMsg.wBuyItemIdx, dwNeedPoint ) )
			{
				SetDisable( FALSE );
				GAMEIN->GetInventoryDialog()->SetDisable( FALSE );
				return;
			}
		}
		break;
	}
	

	NETWORK->Send( &m_buyMsg, sizeof(m_buyMsg) );
}

void CIMDealDialog::CancelBuyItem()
{
	SetDisable( FALSE );
	GAMEIN->GetInventoryDialog()->SetDisable( FALSE );
}

void CIMDealDialog::FakeBuyItem(LONG x, LONG y, CDealItem* pItem)
{
	DWORD itemIdx = pItem->GetItemIdx();
	if( itemIdx == 0 ) return;

	if (m_DealerIdx == 9991)
	{

	}

	if( ITEMMGR->IsDupItem( itemIdx ) )
	{
		// ������ â ����
		m_buyMsg.Category		= MP_ITEM;
		m_buyMsg.Protocol		= MP_ITEM_BUY_SYN;
		m_buyMsg.dwObjectID		= HEROID;
		m_buyMsg.wBuyItemIdx	= itemIdx;
		m_buyMsg.wDealerIdx		= m_DealerIdx;
		//m_buyMsg.BuyItemNum		= 0;

		cDivideBox * pDivideBox = WINDOWMGR->DivideBox( DBOX_BUY, x, y, OnFakeBuyItem, OnCancelBuyItem,
			//070126 LYW --- NPCShop : Modified message number.
														//this, pItem, CHATMGR->GetChatMsg(187) );
														this, pItem, CHATMGR->GetChatMsg(27) );
		if( !pDivideBox )
			return;

		pDivideBox->SetMaxValue( MAX_ITEMBUY_NUM );
//		pDivideBox->SetValue(1);

		SetDisable( TRUE );
		GAMEIN->GetInventoryDialog()->SetDisable( TRUE );

	}
	else
	{
		if( HERO->GetMoney() < pItem->GetBuyPrice() )
		{
			//���� �����մϴ�.
			//070126 LYW --- NPCShop : Modified message number.
			//CHATMGR->AddMsg( CTC_SYSMSG, CHATMGR->GetChatMsg(117) );
			CHATMGR->AddMsg( CTC_SYSMSG, CHATMGR->GetChatMsg(324) );
			return;			
		}

		if( 0<pItem->GetBuyFishPoint() && FISHINGMGR->GetFishPoint() < pItem->GetBuyFishPoint())
		{
			CHATMGR->AddMsg( CTC_SYSMSG, CHATMGR->GetChatMsg( 1533 ) );
			return;			
		}
		
		if( 0 < pItem->GetBuyVipPoint() && VIPMGR->GetVipPoint() < pItem->GetBuyVipPoint())
		{
			CHATMGR->AddMsg( CTC_OPERATOR, CHATMGR->GetChatMsg( 2502 ) );
			return;			
		}
		
		if( 0 < pItem->GetBuyKillPoint() && KILLMGR->GetKillPoint() < pItem->GetBuyKillPoint())
		{
			CHATMGR->AddMsg( CTC_OPERATOR, CHATMGR->GetChatMsg( 2505 ) );
			return;			
		}
		
		if( 0 < pItem->GetBuyRebornPoint() && UTILITYMGR->GetRebornPoint() < pItem->GetBuyRebornPoint())
		{
			CHATMGR->AddMsg( CTC_OPERATOR, CHATMGR->GetChatMsg( 2510 ) );
			return;			
		}

		// 100104 ShinJS --- Item Point Type ����
		ITEM_INFO * pItemInfo = ITEMMGR->GetItemInfo( itemIdx );
		if( !pItemInfo )
			return;

		switch( pItemInfo->wPointType )
		{
			// Coin ����
		case eItemPointType_Item:
			{
				// Coin �������� ���ŷ����� ������ ���
				DWORD dwCoinItemIdx = pItemInfo->dwPointTypeValue1;
				DWORD dwNeedCoinCnt = pItemInfo->dwPointTypeValue2;
				if( !CanBuyCoinItem( itemIdx, dwCoinItemIdx, dwNeedCoinCnt ) )
				{
					return;
				}
			}
			break;

			// PC�� ����Ʈ ����
		case eItemPointType_PCRoomPoint:
			{
				DWORD dwNeedPoint = pItemInfo->dwPointTypeValue1;

				// ����Ʈ ����
				if( !PCROOMMGR->CanBuyItem( itemIdx, dwNeedPoint ) )
				{
					return;
				}
			}
			break;
		}
		
		SetDisable( TRUE );
		GAMEIN->GetInventoryDialog()->SetDisable( TRUE );

		m_buyMsg.Category		= MP_ITEM;
		m_buyMsg.Protocol		= MP_ITEM_BUY_SYN;
		m_buyMsg.dwObjectID		= HEROID;
		m_buyMsg.wBuyItemIdx	= itemIdx;
		m_buyMsg.wDealerIdx		= m_DealerIdx;
		m_buyMsg.BuyItemNum		= 1;

		const MONEYTYPE BuyPrice = pItem->GetBuyPrice();
		char buf[256] = {0,};
		DWORD dwBuyFishPoint = pItem->GetBuyFishPoint();
		DWORD dwBuyVipPoint = pItem->GetBuyVipPoint();
		DWORD dwBuyKillPoint = pItem->GetBuyKillPoint();
		DWORD dwBuyRebornPoint = pItem->GetBuyRebornPoint();
		if(0 < dwBuyFishPoint)
		{
			sprintf(buf, "%s %s", CHATMGR->GetChatMsg( 342 ), CHATMGR->GetChatMsg( 1534 ));

			char temp[32];
			SafeStrCpy(temp, AddComma(BuyPrice), 32 );

			WINDOWMGR->MsgBox( MBI_IMBUYITEM, MBT_YESNO, buf, 
				pItem->GetItemName(), temp, AddComma( dwBuyFishPoint ));
		}

		if(0 < dwBuyVipPoint)
		{
			sprintf(buf, "%s %s", CHATMGR->GetChatMsg( 342 ), CHATMGR->GetChatMsg( 2503 ));

			char temp[32];
			SafeStrCpy(temp, AddComma(BuyPrice), 32 );

			WINDOWMGR->MsgBox( MBI_IMBUYITEM, MBT_YESNO, buf, 
				pItem->GetItemName(), temp, AddComma( dwBuyVipPoint ));
		}

		if(0 < dwBuyKillPoint)
		{
			sprintf(buf, "%s %s", CHATMGR->GetChatMsg( 342 ), CHATMGR->GetChatMsg( 2506 ));

			char temp[32];
			SafeStrCpy(temp, AddComma(BuyPrice), 32 );

			WINDOWMGR->MsgBox( MBI_IMBUYITEM, MBT_YESNO, buf, 
				pItem->GetItemName(), temp, AddComma( dwBuyKillPoint ));
		}

		if(0 < dwBuyRebornPoint)
		{
			sprintf(buf, "%s %s", CHATMGR->GetChatMsg( 342 ), CHATMGR->GetChatMsg( 2511 ));

			char temp[32];
			SafeStrCpy(temp, AddComma(BuyPrice), 32 );

			WINDOWMGR->MsgBox( MBI_IMBUYITEM, MBT_YESNO, buf, 
				pItem->GetItemName(), temp, AddComma( dwBuyRebornPoint ));
		}
		else
		{
			// 100105 ShinJS --- PointType �� ���� Msg ����
			switch( pItemInfo->wPointType )
			{
				// PC�� ����Ʈ ����
			case eItemPointType_PCRoomPoint:
				{
					DWORD dwNeedPoint = pItemInfo->dwPointTypeValue1;

					char buf[MAX_PATH] = {0,};
					char temp[32];
					sprintf( buf, "%s %s", CHATMGR->GetChatMsg( 342 ), CHATMGR->GetChatMsg( 2014 ) );	// "[%s]^n%s���� ��ðڽ��ϱ�? (PC�� ����Ʈ %s �Ҹ�)"
					SafeStrCpy( temp, AddComma( dwNeedPoint ), 32 );

					WINDOWMGR->MsgBox( MBI_IMBUYITEM, MBT_YESNO, buf, 
						pItem->GetItemName(), AddComma( BuyPrice ), temp );
				}
				break;
			default:
				{
					ITEM_INFO* itemInfo = ITEMMGR->GetItemInfo(pItem->GetItemIdx());
					DWORD iMPoints = 0;
					if (itemInfo)
					{
						iMPoints = itemInfo->dwBuyVipPoint;
					}
					WINDOWMGR->MsgBox( MBI_IMBUYITEM, MBT_YESNO, "[%s]^nAre to you going to buy for %s IM Points?", 
						pItem->GetItemName(), AddComma( iMPoints ) );
					//[%s]^nAre to you going to buy for %s gold?"
				}
				break;
			}
			
		}

	}
}

void CIMDealDialog::SetActive(BOOL val)
{
	if( m_bDisable ) return;

	if(val == FALSE)
	{
		HideDealer();
	}
	cTabDialog::SetActive(val);

	// 070326 LYW --- StorageDialog : Close inventory.
	if( !val )
	{
		CInventoryExDialog* pWindow = GAMEIN->GetInventoryDialog() ;

		if( pWindow->IsActive() )
		{
			VECTOR2* pPos = pWindow->GetPrevPos() ;
			pWindow->SetAbsXY( (LONG)pPos->x, (LONG)pPos->y ) ;

			pWindow->SetActive( FALSE ) ;
		}
	}

	SetActivePointInfo( FALSE, 0 );
}
void CIMDealDialog::OnActionEvnet(LONG lId, void * p, DWORD we)
{
	if(we == WE_RBTNCLICK)// ||*/ we == WE_LBTNDBLCLICK)//right click//beyond
	{
		OnBuyPushed();
	}
}

// 070329 LYW --- DealDialog : Add function to setting positio.
void CIMDealDialog::ShowDealDialog( BOOL val )
{
	SetAbsXY( (LONG)m_relPos.x, (LONG)m_relPos.y ) ;

	SetActive( val ) ;

	CInventoryExDialog* pWindow = GAMEIN->GetInventoryDialog() ;

	VECTOR2 vPos = {0, } ;
	vPos.x = pWindow->GetAbsX() ;
	vPos.y = pWindow->GetAbsY() ;

	memcpy( pWindow->GetPrevPos(), &vPos, sizeof(VECTOR2) ) ;

	if( val )
	{
		pWindow->SetAbsXY((LONG)(m_relPos.x + 10) + GetWidth(), (LONG)m_relPos.y ) ;
		
		if (m_DealerIdx != 9991) //Alemuri IM Dealer
			if( !pWindow->IsActive() )pWindow->SetActive( TRUE ) ;
	}

	//Alemuri Calendar Daily Item----------------------------------------------------------------------------------------
	time_t theTime = time(NULL);
	struct tm *aTime = localtime(&theTime);

	int day = aTime->tm_mday;
	int month = aTime->tm_mon + 1; // Month is 0 - 11, add 1 to get a jan-dec 1-12 concept
	int year = aTime->tm_year + 1900; // Year is # years since 1900

	char buffday[3];
	char buffmonth[3];
	char buffyear[5];	
	sprintf(buffday, "%d", day);
	sprintf(buffmonth, "%d", month);
	sprintf(buffyear, "%d", year);

	std::string dayStr(buffday);
	std::string monthStr(buffmonth);
	std::string yearStr(buffyear);
	std::string newDaily = dayStr + "," + monthStr + "," + buffyear;

	if (m_DealerIdx == 9991)
	{

	}

	m_pTitle = (cStatic *)GetWindowForID(IMSTATIC_TITLE);
	if (m_pTitle)
	{
		m_pTitle->SetStaticText("IM Shop");
		//m_pTitle->SetStaticText(CHATMGR->GetChatMsg( 234 ));
	}

	cStatic* rewardTextImg = (cStatic *)GetWindowForID(IMSTATICREWARDTEXT);
	if (rewardTextImg)
		rewardTextImg->SetActive(FALSE);

	cWindow* dailyButton = this->GetWindowForID(IMDE_GETREWARD);
	if (dailyButton)
		dailyButton->SetActive(FALSE);

	cWindow* sellButton = this->GetWindowForID(IMDE_SELLITEM);
	if (sellButton)
		sellButton->SetActive(TRUE);
	cWindow* buyButton = this->GetWindowForID(IMDE_BUYITEM);
	if (buyButton)
		buyButton->SetActive(TRUE);
	cWindow* cancelButton = this->GetWindowForID(IMDE_CANCEL);
	if (cancelButton)
		cancelButton->SetActive(TRUE);
	cWindow* tab7Button = this->GetWindowForID(IMDE_TABBTN7);
	if (tab7Button)
		tab7Button->SetActive(TRUE);
	cWindow* tab6Button = this->GetWindowForID(IMDE_TABBTN6);
	if (tab6Button)
		tab6Button->SetActive(TRUE);
	cWindow* tab5Button = this->GetWindowForID(IMDE_TABBTN5);
	if (tab5Button)
		tab5Button->SetActive(TRUE);
	cWindow* tab4Button = this->GetWindowForID(IMDE_TABBTN4);
	if (tab4Button)
		tab4Button->SetActive(TRUE);
	cWindow* tab3Button = this->GetWindowForID(IMDE_TABBTN3);
	if (tab3Button)
		tab3Button->SetActive(TRUE);
	cWindow* tab2Button = this->GetWindowForID(IMDE_TABBTN2);
	if (tab2Button)
		tab2Button->SetActive(TRUE);
	cWindow* staticMoneyEdit = this->GetWindowForID(IMSTATICMONEYEDIT);
	if (staticMoneyEdit)
	{
		staticMoneyEdit->SetAlpha(255);
		staticMoneyEdit->SetActive(TRUE);
	}
	cWindow* moneyEdit = this->GetWindowForID(IMDE_MONEYEDIT);
	if (moneyEdit)
	{
		moneyEdit->SetAlpha(255);
		moneyEdit->SetActive(TRUE);
	}
	cWindow* staticPointEdit = this->GetWindowForID(IMSTATICPOINTEDIT);
	if (staticPointEdit)
	{
		staticPointEdit->SetAlpha(255);
		staticPointEdit->SetActive(TRUE);
	}
	cWindow* pointEdit = this->GetWindowForID(IMDE_POINTEDIT);
	if (pointEdit)
	{
		pointEdit->SetAlpha(255);
		pointEdit->SetActive(TRUE);
	}
	cWindow* staticPointImage = this->GetWindowForID(IMDE_POINTIMG);
	if (staticPointImage)
	{
		staticPointImage->SetAlpha(255);
		staticPointImage->SetActive(TRUE);
	}	
	//-------------------------------------------------------------------------------------------------------------------
}

// 090227 ShinJS --- Coin Item�� ���԰��ɿ��� �Ǵ��Լ�
BOOL CIMDealDialog::CanBuyCoinItem( DWORD dwBuyItemIdx, DWORD dwCoinType, DWORD dwCoinCnt ) const
{
	ITEM_INFO * pBuyItemInfo = ITEMMGR->GetItemInfo( dwBuyItemIdx );
	ITEM_INFO * pCoinItemInfo = ITEMMGR->GetItemInfo( dwCoinType );
	if( !pBuyItemInfo || !pCoinItemInfo )
		return FALSE;

	const POSTYPE inventoryStartPosition = TP_INVENTORY_START;
	const POSTYPE inventoryEndPosition = POSTYPE(TP_INVENTORY_END + TABCELL_INVENTORY_NUM * HERO->Get_HeroExtendedInvenCount());
	CInventoryExDialog* inventory = ( CInventoryExDialog* )WINDOWMGR->GetWindowForID( IN_INVENTORYDLG );
	if( !inventory )		return FALSE;

	DWORD dwCoinCntOfInventory = 0;

	// �κ��丮�� �˻��Ͽ� �ش� Coin�� ���������� ���Ѵ�
	for( POSTYPE position = inventoryStartPosition ; inventoryEndPosition > position ; ++position )
	{
		CItem* item = inventory->GetItemForPos( position );
		if( !item )		continue;

		const DWORD	itemIndex	= item->GetItemIdx();

		// �ش� Coin�� ���
		if( itemIndex == dwCoinType )
		{
			const BOOL	isDuplicate = ITEMMGR->IsDupItem( itemIndex );
			const DWORD quantity	= ( isDuplicate ? item->GetDurability() : 1 );

			dwCoinCntOfInventory += quantity;
		}
	}

	// ������ ������ ���
	if( dwCoinCntOfInventory < dwCoinCnt )
	{
		CHATMGR->AddMsg( CTC_SYSMSG, CHATMGR->GetChatMsg(1908), pBuyItemInfo->ItemName, pCoinItemInfo->ItemName, dwCoinCnt - dwCoinCntOfInventory );
		return FALSE;
	}

	return TRUE;
}

void CIMDealDialog::SetActivePointInfo( BOOL bShow, DWORD dwPoint )
{
	m_pPointEdit->SetActive( bShow );
	m_pPointImage->SetActive( bShow );

	m_pPointEdit->SetStaticValue( LONG( dwPoint ) );

	if (m_DealerIdx == 9991)
	{

	}

	m_pPointEdit->SetAlpha(255);
	m_pPointEdit->SetActive(TRUE);	

}

BOOL CIMDealDialog::IsActivePointInfo()
{
	return m_pPointEdit->IsActive();
}

///Alemuri Calendar Daily Item----------------------------------------------------------------------------------
void CIMDealDialog::OnDailyPushed()
{
	time_t theTime = time(NULL);
	struct tm *aTime = localtime(&theTime);

	int day = aTime->tm_mday;
	int month = aTime->tm_mon + 1; // Month is 0 - 11, add 1 to get a jan-dec 1-12 concept
	int year = aTime->tm_year + 1900; // Year is # years since 1900

	char buffday[3];
	char buffmonth[3];
	char buffyear[5];	
	sprintf(buffday, "%d", day);
	sprintf(buffmonth, "%d", month);
	sprintf(buffyear, "%d", year);

	std::string dayStr(buffday);
	std::string monthStr(buffmonth);
	std::string yearStr(buffyear);
	std::string newDaily = dayStr + "," + monthStr + "," + buffyear;

	if (m_DealerIdx == 9991)
	{

	}

	MSGBASE msg;
	ZeroMemory( &msg, sizeof(msg) );
	msg.Category = MP_PCROOM;
	msg.Protocol = MP_PCROOM2_DAILYITEM_SYN;
	msg.dwObjectID = HEROID;
	NETWORK->Send( &msg, sizeof(msg) );
}
//--------------------------------------------------------------------------------------------------------------


//Alemuri IM In Game---------------------------------------------------------
enum IM_Slots_Image
{
	//page 1
	Page_1_Slot_1 =		205,
	Page_1_Slot_2 =		206,
	Page_1_Slot_3 =		0,
	Page_1_Slot_4 =		0,
	Page_1_Slot_5 =		0,
	Page_1_Slot_6 =		0,
	Page_1_Slot_7 =		0,
	Page_1_Slot_8 =		0,
	Page_1_Slot_9 =		0,
	Page_1_Slot_10 =	0,
	Page_1_Slot_11 =	0,
	Page_1_Slot_12 =	0,
	Page_1_Slot_13 =	0,
	Page_1_Slot_14 =	0,
	Page_1_Slot_15 =	0,
	Page_1_Slot_16 =	0,
	Page_1_Slot_17 =	0,
	Page_1_Slot_18 =	0,
	Page_1_Slot_19 =	0,
	Page_1_Slot_20 =	0,
	Page_1_Slot_21 =	0,
	Page_1_Slot_22 =	0,
	Page_1_Slot_23 =	0,
	Page_1_Slot_24 =	0,
	Page_1_Slot_25 =	0,
	Page_1_Slot_26 =	0,
	Page_1_Slot_27 =	0,
	Page_1_Slot_28 =	0,
	Page_1_Slot_29 =	0,
	Page_1_Slot_30 =	0,
	Page_1_Slot_31 =	0,
	Page_1_Slot_32 =	0,
	Page_1_Slot_33 =	0,
	Page_1_Slot_34 =	0,
	Page_1_Slot_35 =	0,
	Page_1_Slot_36 =	0,
	//page 2
	Page_2_Slot_1 =		206,
	Page_2_Slot_2 =		0,
	Page_2_Slot_3 =		0,
	Page_2_Slot_4 =		0,
	Page_2_Slot_5 =		0,
	Page_2_Slot_6 =		0,
	Page_2_Slot_7 =		0,
	Page_2_Slot_8 =		0,
	Page_2_Slot_9 =		0,
	Page_2_Slot_10 =	0,
	Page_2_Slot_11 =	0,
	Page_2_Slot_12 =	0,
	Page_2_Slot_13 =	0,
	Page_2_Slot_14 =	0,
	Page_2_Slot_15 =	0,
	Page_2_Slot_16 =	0,
	Page_2_Slot_17 =	0,
	Page_2_Slot_18 =	0,
	Page_2_Slot_19 =	0,
	Page_2_Slot_20 =	0,
	Page_2_Slot_21 =	0,
	Page_2_Slot_22 =	0,
	Page_2_Slot_23 =	0,
	Page_2_Slot_24 =	0,
	Page_2_Slot_25 =	0,
	Page_2_Slot_26 =	0,
	Page_2_Slot_27 =	0,
	Page_2_Slot_28 =	0,
	Page_2_Slot_29 =	0,
	Page_2_Slot_30 =	0,
	Page_2_Slot_31 =	0,
	Page_2_Slot_32 =	0,
	Page_2_Slot_33 =	0,
	Page_2_Slot_34 =	0,
	Page_2_Slot_35 =	0,
	Page_2_Slot_36 =	0,
	//page 3
	Page_3_Slot_1 =		0,
	Page_3_Slot_2 =		0,
	Page_3_Slot_3 =		0,
	Page_3_Slot_4 =		0,
	Page_3_Slot_5 =		0,
	Page_3_Slot_6 =		0,
	Page_3_Slot_7 =		0,
	Page_3_Slot_8 =		0,
	Page_3_Slot_9 =		0,
	Page_3_Slot_10 =	0,
	Page_3_Slot_11 =	0,
	Page_3_Slot_12 =	0,
	Page_3_Slot_13 =	0,
	Page_3_Slot_14 =	0,
	Page_3_Slot_15 =	0,
	Page_3_Slot_16 =	0,
	Page_3_Slot_17 =	0,
	Page_3_Slot_18 =	0,
	Page_3_Slot_19 =	0,
	Page_3_Slot_20 =	0,
	Page_3_Slot_21 =	0,
	Page_3_Slot_22 =	0,
	Page_3_Slot_23 =	0,
	Page_3_Slot_24 =	0,
	Page_3_Slot_25 =	0,
	Page_3_Slot_26 =	0,
	Page_3_Slot_27 =	0,
	Page_3_Slot_28 =	0,
	Page_3_Slot_29 =	0,
	Page_3_Slot_30 =	0,
	Page_3_Slot_31 =	0,
	Page_3_Slot_32 =	0,
	Page_3_Slot_33 =	0,
	Page_3_Slot_34 =	0,
	Page_3_Slot_35 =	0,
	Page_3_Slot_36 =	0,
	//page 4
	Page_4_Slot_1 =		0,
	Page_4_Slot_2 =		0,
	Page_4_Slot_3 =		0,
	Page_4_Slot_4 =		0,
	Page_4_Slot_5 =		0,
	Page_4_Slot_6 =		0,
	Page_4_Slot_7 =		0,
	Page_4_Slot_8 =		0,
	Page_4_Slot_9 =		0,
	Page_4_Slot_10 =	0,
	Page_4_Slot_11 =	0,
	Page_4_Slot_12 =	0,
	Page_4_Slot_13 =	0,
	Page_4_Slot_14 =	0,
	Page_4_Slot_15 =	0,
	Page_4_Slot_16 =	0,
	Page_4_Slot_17 =	0,
	Page_4_Slot_18 =	0,
	Page_4_Slot_19 =	0,
	Page_4_Slot_20 =	0,
	Page_4_Slot_21 =	0,
	Page_4_Slot_22 =	0,
	Page_4_Slot_23 =	0,
	Page_4_Slot_24 =	0,
	Page_4_Slot_25 =	0,
	Page_4_Slot_26 =	0,
	Page_4_Slot_27 =	0,
	Page_4_Slot_28 =	0,
	Page_4_Slot_29 =	0,
	Page_4_Slot_30 =	0,
	Page_4_Slot_31 =	0,
	Page_4_Slot_32 =	0,
	Page_4_Slot_33 =	0,
	Page_4_Slot_34 =	0,
	Page_4_Slot_35 =	0,
	Page_4_Slot_36 =	0,
	//page 5
	Page_5_Slot_1 =		0,
	Page_5_Slot_2 =		0,
	Page_5_Slot_3 =		0,
	Page_5_Slot_4 =		0,
	Page_5_Slot_5 =		0,
	Page_5_Slot_6 =		0,
	Page_5_Slot_7 =		0,
	Page_5_Slot_8 =		0,
	Page_5_Slot_9 =		0,
	Page_5_Slot_10 =	0,
	Page_5_Slot_11 =	0,
	Page_5_Slot_12 =	0,
	Page_5_Slot_13 =	0,
	Page_5_Slot_14 =	0,
	Page_5_Slot_15 =	0,
	Page_5_Slot_16 =	0,
	Page_5_Slot_17 =	0,
	Page_5_Slot_18 =	0,
	Page_5_Slot_19 =	0,
	Page_5_Slot_20 =	0,
	Page_5_Slot_21 =	0,
	Page_5_Slot_22 =	0,
	Page_5_Slot_23 =	0,
	Page_5_Slot_24 =	0,
	Page_5_Slot_25 =	0,
	Page_5_Slot_26 =	0,
	Page_5_Slot_27 =	0,
	Page_5_Slot_28 =	0,
	Page_5_Slot_29 =	0,
	Page_5_Slot_30 =	0,
	Page_5_Slot_31 =	0,
	Page_5_Slot_32 =	0,
	Page_5_Slot_33 =	0,
	Page_5_Slot_34 =	0,
	Page_5_Slot_35 =	0,
	Page_5_Slot_36 =	0,
	//page 6
	Page_6_Slot_1 =		0,
	Page_6_Slot_2 =		0,
	Page_6_Slot_3 =		0,
	Page_6_Slot_4 =		0,
	Page_6_Slot_5 =		0,
	Page_6_Slot_6 =		0,
	Page_6_Slot_7 =		0,
	Page_6_Slot_8 =		0,
	Page_6_Slot_9 =		0,
	Page_6_Slot_10 =	0,
	Page_6_Slot_11 =	0,
	Page_6_Slot_12 =	0,
	Page_6_Slot_13 =	0,
	Page_6_Slot_14 =	0,
	Page_6_Slot_15 =	0,
	Page_6_Slot_16 =	0,
	Page_6_Slot_17 =	0,
	Page_6_Slot_18 =	0,
	Page_6_Slot_19 =	0,
	Page_6_Slot_20 =	0,
	Page_6_Slot_21 =	0,
	Page_6_Slot_22 =	0,
	Page_6_Slot_23 =	0,
	Page_6_Slot_24 =	0,
	Page_6_Slot_25 =	0,
	Page_6_Slot_26 =	0,
	Page_6_Slot_27 =	0,
	Page_6_Slot_28 =	0,
	Page_6_Slot_29 =	0,
	Page_6_Slot_30 =	0,
	Page_6_Slot_31 =	0,
	Page_6_Slot_32 =	0,
	Page_6_Slot_33 =	0,
	Page_6_Slot_34 =	0,
	Page_6_Slot_35 =	0,
	Page_6_Slot_36 =	0,
};

DWORD CIMDealDialog::GetHardImageForIMSlot(POSTYPE position)
{
	switch( position )
	{		
	case 0:
		return Page_1_Slot_1;
	case 1:
		return Page_1_Slot_2;
	case 2:
		return Page_1_Slot_3;
	case 3:
		return Page_1_Slot_4;
	case 4:
		return Page_1_Slot_5;
	case 5:
		return Page_1_Slot_6;
	case 6:
		return Page_1_Slot_7;
	case 7:
		return Page_1_Slot_8;
	case 8:
		return Page_1_Slot_9;
	case 9:
		return Page_1_Slot_10;
	case 10:
		return Page_1_Slot_11;
	case 11:
		return Page_1_Slot_12;
	case 12:
		return Page_1_Slot_13;
	case 13:
		return Page_1_Slot_14;
	case 14:
		return Page_1_Slot_15;
	case 15:
		return Page_1_Slot_16;
	case 16:
		return Page_1_Slot_17;
	case 17:
		return Page_1_Slot_18;
	case 18:
		return Page_1_Slot_19;
	case 19:
		return Page_1_Slot_20;
	case 20:
		return Page_1_Slot_21;
	case 21:
		return Page_1_Slot_22;
	case 22:
		return Page_1_Slot_23;
	case 23:
		return Page_1_Slot_24;
	case 24:
		return Page_1_Slot_25;
	case 25:
		return Page_1_Slot_26;
	case 26:
		return Page_1_Slot_27;
	case 27:
		return Page_1_Slot_28;
	case 28:
		return Page_1_Slot_29;
	case 29:
		return Page_1_Slot_30;
	case 30:
		return Page_1_Slot_31;
	case 31:
		return Page_1_Slot_32;
	case 32:
		return Page_1_Slot_33;
	case 33:
		return Page_1_Slot_34;
	case 34:
		return Page_1_Slot_35;
	case 35:
		return Page_1_Slot_36;
		//Page 2
	case 36:
		return Page_2_Slot_1;
	case 37:
		return Page_2_Slot_2;
	case 38:
		return Page_2_Slot_3;
	case 39:
		return Page_2_Slot_4;
	case 40:
		return Page_2_Slot_5;
	case 41:
		return Page_2_Slot_6;
	case 42:
		return Page_2_Slot_7;
	case 43:
		return Page_2_Slot_8;
	case 44:
		return Page_2_Slot_9;
	case 45:
		return Page_2_Slot_10;
	case 46:
		return Page_2_Slot_11;
	case 47:
		return Page_2_Slot_12;
	case 48:
		return Page_2_Slot_13;
	case 49:
		return Page_2_Slot_14;
	case 50:
		return Page_2_Slot_15;
	case 51:
		return Page_2_Slot_16;
	case 52:
		return Page_2_Slot_17;
	case 53:
		return Page_2_Slot_18;
	case 54:
		return Page_2_Slot_19;
	case 55:
		return Page_2_Slot_20;
	case 56:
		return Page_2_Slot_21;
	case 57:
		return Page_2_Slot_22;
	case 58:
		return Page_2_Slot_23;
	case 59:
		return Page_2_Slot_24;
	case 60:
		return Page_2_Slot_25;
	case 61:
		return Page_2_Slot_26;
	case 62:
		return Page_2_Slot_27;
	case 63:
		return Page_2_Slot_28;
	case 64:
		return Page_2_Slot_29;
	case 65:
		return Page_2_Slot_30;
	case 66:
		return Page_2_Slot_31;
	case 67:
		return Page_2_Slot_32;
	case 68:
		return Page_2_Slot_33;
	case 69:
		return Page_2_Slot_34;
	case 70:
		return Page_2_Slot_35;
	case 71:
		return Page_2_Slot_36;
		//Page 3
	case 72:
		return Page_3_Slot_1;
	case 73:
		return Page_3_Slot_2;
	case 74:
		return Page_3_Slot_3;
	case 75:
		return Page_3_Slot_4;
	case 76:
		return Page_3_Slot_5;
	case 77:
		return Page_3_Slot_6;
	case 78:
		return Page_3_Slot_7;
	case 79:
		return Page_3_Slot_8;
	case 80:
		return Page_3_Slot_9;
	case 81:
		return Page_3_Slot_10;
	case 82:
		return Page_3_Slot_11;
	case 83:
		return Page_3_Slot_12;
	case 84:
		return Page_3_Slot_13;
	case 85:
		return Page_3_Slot_14;
	case 86:
		return Page_3_Slot_15;
	case 87:
		return Page_3_Slot_16;
	case 88:
		return Page_3_Slot_17;
	case 89:
		return Page_3_Slot_18;
	case 90:
		return Page_3_Slot_19;
	case 91:
		return Page_3_Slot_20;
	case 92:
		return Page_3_Slot_21;
	case 93:
		return Page_3_Slot_22;
	case 94:
		return Page_3_Slot_23;
	case 95:
		return Page_3_Slot_24;
	case 96:
		return Page_3_Slot_25;
	case 97:
		return Page_3_Slot_26;
	case 98:
		return Page_3_Slot_27;
	case 99:
		return Page_3_Slot_28;
	case 100:
		return Page_3_Slot_29;
	case 101:
		return Page_3_Slot_30;
	case 102:
		return Page_3_Slot_31;
	case 103:
		return Page_3_Slot_32;
	case 104:
		return Page_3_Slot_33;
	case 105:
		return Page_3_Slot_34;
	case 106:
		return Page_3_Slot_35;
	case 107:
		return Page_3_Slot_36;
		//Page 4
	case 108:
		return Page_4_Slot_1;
	case 109:
		return Page_4_Slot_2;
	case 110:
		return Page_4_Slot_3;
	case 111:
		return Page_4_Slot_4;
	case 112:
		return Page_4_Slot_5;
	case 113:
		return Page_4_Slot_6;
	case 114:
		return Page_4_Slot_7;
	case 115:
		return Page_4_Slot_8;
	case 116:
		return Page_4_Slot_9;
	case 117:
		return Page_4_Slot_10;
	case 118:
		return Page_4_Slot_11;
	case 119:
		return Page_4_Slot_12;
	case 120:
		return Page_4_Slot_13;
	case 121:
		return Page_4_Slot_14;
	case 122:
		return Page_4_Slot_15;
	case 123:
		return Page_4_Slot_16;
	case 124:
		return Page_4_Slot_17;
	case 125:
		return Page_4_Slot_18;
	case 126:
		return Page_4_Slot_19;
	case 127:
		return Page_4_Slot_20;
	case 128:
		return Page_4_Slot_21;
	case 129:
		return Page_4_Slot_22;
	case 130:
		return Page_4_Slot_23;
	case 131:
		return Page_4_Slot_24;
	case 132:
		return Page_4_Slot_25;
	case 133:
		return Page_4_Slot_26;
	case 134:
		return Page_4_Slot_27;
	case 135:
		return Page_4_Slot_28;
	case 136:
		return Page_4_Slot_29;
	case 137:
		return Page_4_Slot_30;
	case 138:
		return Page_4_Slot_31;
	case 139:
		return Page_4_Slot_32;
	case 140:
		return Page_4_Slot_33;
	case 141:
		return Page_4_Slot_34;
	case 142:
		return Page_4_Slot_35;
	case 143:
		return Page_4_Slot_36;
		//Page 5
	case 144:
		return Page_5_Slot_1;
	case 145:
		return Page_5_Slot_2;
	case 146:
		return Page_5_Slot_3;
	case 147:
		return Page_5_Slot_4;
	case 148:
		return Page_5_Slot_5;
	case 149:
		return Page_5_Slot_6;
	case 150:
		return Page_5_Slot_7;
	case 151:
		return Page_5_Slot_8;
	case 152:
		return Page_5_Slot_9;
	case 153:
		return Page_5_Slot_10;
	case 154:
		return Page_5_Slot_11;
	case 155:
		return Page_5_Slot_12;
	case 156:
		return Page_5_Slot_13;
	case 157:
		return Page_5_Slot_14;
	case 158:
		return Page_5_Slot_15;
	case 159:
		return Page_5_Slot_16;
	case 160:
		return Page_5_Slot_17;
	case 161:
		return Page_5_Slot_18;
	case 162:
		return Page_5_Slot_19;
	case 163:
		return Page_5_Slot_20;
	case 164:
		return Page_5_Slot_21;
	case 165:
		return Page_5_Slot_22;
	case 166:
		return Page_5_Slot_23;
	case 167:
		return Page_5_Slot_24;
	case 168:
		return Page_5_Slot_25;
	case 169:
		return Page_5_Slot_26;
	case 170:
		return Page_5_Slot_27;
	case 171:
		return Page_5_Slot_28;
	case 172:
		return Page_5_Slot_29;
	case 173:
		return Page_5_Slot_30;
	case 174:
		return Page_5_Slot_31;
	case 175:
		return Page_5_Slot_32;
	case 176:
		return Page_5_Slot_33;
	case 177:
		return Page_5_Slot_34;
	case 178:
		return Page_5_Slot_35;
	case 179:
		return Page_5_Slot_36;
		//Page 6
	case 180:
		return Page_6_Slot_1;
	case 181:
		return Page_6_Slot_2;
	case 182:
		return Page_6_Slot_3;
	case 183:
		return Page_6_Slot_4;
	case 184:
		return Page_6_Slot_5;
	case 185:
		return Page_6_Slot_6;
	case 186:
		return Page_6_Slot_7;
	case 187:
		return Page_6_Slot_8;
	case 188:
		return Page_6_Slot_9;
	case 189:
		return Page_6_Slot_10;
	case 190:
		return Page_6_Slot_11;
	case 191:
		return Page_6_Slot_12;
	case 192:
		return Page_6_Slot_13;
	case 193:
		return Page_6_Slot_14;
	case 194:
		return Page_6_Slot_15;
	case 195:
		return Page_6_Slot_16;
	case 196:
		return Page_6_Slot_17;
	case 197:
		return Page_6_Slot_18;
	case 198:
		return Page_6_Slot_19;
	case 199:
		return Page_6_Slot_20;
	case 200:
		return Page_6_Slot_21;
	case 201:
		return Page_6_Slot_22;
	case 202:
		return Page_6_Slot_23;
	case 203:
		return Page_6_Slot_24;
	case 204:
		return Page_6_Slot_25;
	case 205:
		return Page_6_Slot_26;
	case 206:
		return Page_6_Slot_27;
	case 207:
		return Page_6_Slot_28;
	case 208:
		return Page_6_Slot_29;
	case 209:
		return Page_6_Slot_30;
	case 210:
		return Page_6_Slot_31;
	case 211:
		return Page_6_Slot_32;
	case 212:
		return Page_6_Slot_33;
	case 213:
		return Page_6_Slot_34;
	case 214:
		return Page_6_Slot_35;
	case 215:
		return Page_6_Slot_36;
		}
}
//---------------------------------------------------------------------------