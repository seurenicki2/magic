// EffectTriggerIllusionUnitDesc.cpp: implementation of the CEffectTriggerIllusionUnitDesc class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "EffectTriggerIllusionUnitDesc.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CEffectTriggerIllusionUnitDesc::CEffectTriggerIllusionUnitDesc(DWORD dwTime,DWORD dwUnitNum)
:	CEffectTriggerUnitDesc(dwTime,dwUnitNum)
{
	m_TargetKind = eTargetKind_Weapon;
	m_SwitchKind = eSwitchKind_End;
	m_IllusionFrame = 3;
	m_MaterialNum = 0;
}

CEffectTriggerIllusionUnitDesc::~CEffectTriggerIllusionUnitDesc()
{

}


void CEffectTriggerIllusionUnitDesc::ParseScript(CMHFile* pFile)
{
	char buf[128];
	pFile->GetString(buf);	// skip  '{'
	if(buf[0] != '{')
	{
		ERRORBSGBOX("ERROR[%s]!! { } �� �ʿ��� Ʈ�����Դϴ�!!!",pFile->GetFileName());
		return;
	}

	while(1)
	{
		pFile->GetString(buf);
		CMD_ST(buf)
			CMD_CS("}")
				break;
			CMD_CS("#TARGET")
				pFile->GetString(buf);
				CMD_ST(buf)
					CMD_CS("WEAPON")
						m_TargetKind = eTargetKind_Weapon;
				CMD_EN

			CMD_CS("#MATERIAL")
				m_MaterialNum = pFile->GetWord();
			
			CMD_CS("#SWITCH")
				pFile->GetString(buf);
				CMD_ST(buf)
					CMD_CS("START")
						m_SwitchKind = eSwitchKind_Start;
					CMD_CS("END")
						m_SwitchKind = eSwitchKind_End;
				CMD_EN

			CMD_CS("#FRAME")
				m_IllusionFrame = pFile->GetDword();

		CMD_EN
	}
}
BOOL CEffectTriggerIllusionUnitDesc::Operate(CEffect* pEffect)
{
	return TRUE;
}

